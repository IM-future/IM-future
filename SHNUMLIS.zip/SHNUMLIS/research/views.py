from django.shortcuts import render

def research(request):
    return render(request, '科研/research.html')


