from django.apps import AppConfig


class TeachConfig(AppConfig):
    name = 'teach'
