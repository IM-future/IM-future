from django.http import JsonResponse
from django.shortcuts import render
from teach.models import gzzdModel
from django.core import serializers
import json



# Create your views here.
def teach(request):
    return render(request, '教学/teach.html')


def apiGzzdList(request):
    list = gzzdModel.objects.all()[0:5]
    returnJson = {}
    ss = serializers.serialize('json', list)

    returnJson['result'] = json.loads(ss)
    print(returnJson)
    return JsonResponse(returnJson, safe=False)