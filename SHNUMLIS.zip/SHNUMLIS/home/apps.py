from django.apps import AppConfig


class MlisConfig(AppConfig):
    name = 'home'
