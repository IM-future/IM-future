from rest_framework import serializers

# 自定义书籍序列化器,表单form这么写这就怎么写
class BookSerializers(serializers.Serializer):
    bid = serializers.IntegerField(min_value=0)
    btitle = serializers.CharField(max_length=200)
    bpub_date = serializers.DateTimeField()
    bread = serializers.IntegerField(min_value=0)
    bcomment = serializers.IntegerField(min_value=0)
    bimage = serializers.CharField(max_length=200)

    # 如果想用序列化器把数据存数据库，还得写create和update方法
    # queryset是一个查询集合，有多个对象