from django.http import HttpResponse
from django.shortcuts import render
from rest_framework.generics import GenericAPIView
from home.models import Bookinfo
from home.serializers import BookSerializers
from rest_framework.response import Response

class BookInfoView(GenericAPIView):
    # 继承APIView，使用rest_framework.GenericAPIView更好

    queryset = Bookinfo.objects.all()  # 查询数据库Bookinfo里所有图书
    def get(self,request,bid=-1):
        # # 序列化就是把 对象 或者 queryset 直接转换为 字典 or 列表套字典，
        # # 如果是queryset则必须把many设为True，如果是对象，不用设置。
        # bs = BookSerializers(instance=self.queryset.all(), many=True)   # 序列化
        # print(bs.data)            # 调试界面
        # # return Response(bs.data)  # 返回数据，序列化后，data就是一个字典

        if bid < 0:
            return self.find_many(request)
        return self.find_one(request, bid)

    def find_many(self, request):
        bs = BookSerializers(instance=self.queryset.all(), many=True)  # 获取所有数据
        # print(bs.data)  # 调试代码
        return Response(data=bs.data)  # 序列化后，data就是一个字典

    def find_one(self, request, bid):
        # drf的核心是request，Response以及序列化
        # print(bid)  # 调试代码
        # book = self.queryset.filter(pk=bid) 不能用filter过滤器，filter是个结果集
        book = self.queryset.get(pk=bid)    # 查出结果
        bs = BookSerializers(instance=book)  # 序列化
        # print(bs.data)   # print(res, type(res))
        return Response(bs.data)    # 返回数据

def home(request):
    return render(request, 'index.html')   # 渲染首页模板

def teacher(request):
    return render(request, '师资/teacher.html')


def szgk(request):
    return render(request, '师资/szgk.html')


def teacher01(request):
    return render(request, '师资/zhc.html')

