(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
$(function () {
	var doccenter = {
		seachForm: function () {
			$('.J_searchIpt').on('focus', function () {
		        $(this).parents('.search').addClass('search-focus');
		    }).on('blur', function () {$(this).parents('.search').removeClass('search-focus');});

		    $('.J_SearchBtn').on('click', function () {
		        $('#search-form').submit();
		    });
		},

		typeTab: function () {
			$('.J_typeTabpanel li').each(function (idx, elem) {
				$(elem).on('click', function () {
					if (!$(this).hasClass('cur')) {
						$(this).addClass('cur').siblings().removeClass('cur');
						$('.J_showCon_' + (idx+1), '.J_TypeTabcon').show().siblings().hide();
					}
				});
			});
		},

		topMenu: function () {
			var $document = $(document), docHeight = $document.height();
			var $menu = $('.J_menuList'), $mask = $('.J_menuMask');
			$menu.height(docHeight);

			if ($menu.length){
				$document.on('click', function (e) {
					var clsName = e.target.className;
					if (clsName.indexOf('J_menuIcon') > 0) {
			            $menu.addClass('menu-list-wrap-visible');
			            $mask.addClass('menu-overlay-mask-visible');
			        } else if ($menu.hasClass('menu-list-wrap-visible')) {
			            $menu.removeClass('menu-list-wrap-visible');
			            $mask.removeClass('menu-overlay-mask-visible');
			        }
				});
			}
		},

		iconFont: function () {
		    $('.iconfont').each(function (idx, elem) {
		        var iconf = $(elem).attr("data-iconf");
		        var iconb = $(elem).attr("data-iconb");
		        if(iconf && iconb){
		            $(elem).html(iconf+iconb);
		        }
		    });
		},

		onResize: function () {
			var ua = navigator.userAgent.toLowerCase();

			var version = function () {
				var	isIE = ua.indexOf('msie') > -1,
					v = isIE ? /\d+/.exec(ua.split(';')[1]) : 'no ie';
				return v;
			};

			var responsive = function () {
				var viewportWidth = $(window).width();
				if(viewportWidth < 1240){
					$('body').addClass('narrow');
				} else {
					$('body').removeClass('narrow');
				}
			};
			responsive();

			if (version() < 10) {
				$(window).on('resize', function () {
					responsive();
				});
			}

			if (ua.indexOf("windows") > 0) {
				$("html").addClass("win");
			}
		},

		//初始化
		init: function () {
			this.seachForm(); //搜索表单事件
			this.typeTab(); //类型选项卡
			this.topMenu(); //api一级菜单
			this.iconFont(); //iconfont tms下拼接
			this.onResize(); //窗口缩放
		}
	};

	doccenter.init();
});

},{}]},{},[1])