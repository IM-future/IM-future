new Vue({
    el:'#pages',
    data:{
        pageCount:10,
        gzzd_list:[],
        pyfa_list:[],
        jxtz_list:[],

    },
    mounted:function (){
        this.initPage();
    },
    methods:{
        initPage:function (){
            url = '/api/teach/gzzdlist';
            axios.get(url)
                .then((response) =>{
                    console.log(response.data.result[0].fields.author);
                    this.gzzd_list = response.data.result;
                    console.log(this.gzzd_list)

                })
        }
    }
})